SELECT * FROM Employee
DROP PROCEDURE IF EXISTS dbo.GetEmployeeDetails; 
CREATE PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
 --@employeeId INT       --camelCase
AS
BEGIN
 SET NOCOUNT ON;

SELECT	FirstName,
	    LastName
FROM	Employee

END
-----CALL----
EXECUTE GetEmployeeDetails 
---------------------------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
 @employeeId INT = 0    --Default  --camelCase
AS
BEGIN
	SET NOCOUNT ON;
	IF(@employeeId > 0)
		BEGIN
				SELECT	FirstName,
						LastName
				FROM	Employee
				Where	EmployeeId = @employeeId
		END
	ELSE
		BEGIN
				SELECT	FirstName,
						LastName
				FROM	Employee
		END
END
---CALL---
EXECUTE GetEmployeeDetails 10
------------------------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
 @employeeId INT = 0      --camelCase
AS
BEGIN
		SET NOCOUNT ON;

		SELECT	FirstName,
				LastName
		FROM	Employee
		WHERE	EmployeeId = IIF(@employeeId > 0, @employeeId, EmployeeId)
END

EXECUTE GetEmployeeDetails 11
----------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails]
@employeeId INT = 0 
AS
BEGIN
		SET NOCOUNT ON;
		UPDATE emp
		SET		emp.Salary = 40000
		FROM	Employee emp
		WHERE	EmployeeId = IIF(@employeeId > 0, @employeeId, EmployeeId)

		SELECT	FirstName,
				LastName,
				Salary
		FROM	Employee
		WHERE EmployeeId = IIF(@employeeId > 0, @employeeId, EmployeeId)
END

EXECUTE GetEmployeeDetails 10
---------------------------------------------------------------------------
DROP VIEW	EmployeeCompany

CREATE VIEW EmployeeCompany
AS
	SELECT		Stu.[Name] AS StudentName,
				Stu.Age,
				DeptRecord.[Name] AS DepartmentName
	FROM		Students Stu
	INNER JOIN	Departments AS DeptRecord
	ON			DeptRecord.DepartmentID = Stu.DepartmentId

	SELECT * FROM EmployeeCompany
-------------------------------------------------------------------------------------
---Scalar Function - Retuen single value
CREATE FUNCTION [dbo].[CalculateEBill]
(
	 @unit	INT,
	 @rate	DECIMAL(18, 2)
)
RETURNS		DECIMAL(18, 2)
AS
BEGIN
	 DECLARE @eBill DECIMAL(18, 2)
	 SET @EBill = @unit * @rate
	 RETURN @EBill 
END
--CALL--
SELECT [dbo].[CalculateEBill](1.2, 5.5) AS BILL
------------------------------------------------------------------------------
--TABLE VALUED FUNCTION-----return data in table type
CREATE FUNCTION [dbo].[GetEmployeeData]
(
 @companyId INT
)
RETURNS TABLE
AS
RETURN
	SELECT * FROM Employee
---CALL---
	SELECT * FROM [dbo].[GetEmployeeData](1)
-------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[GetSalaryIncrement]
(
 @salary   DECIMAL(18, 2),
 @performance INT = 0
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
  DECLARE @rate DECIMAL(18, 2)

  SET @rate =  CASE
       WHEN @performance = 1 THEN 0.05
       WHEN @performance = 2 THEN 0.10
       WHEN @performance = 3 THEN 0.20
       WHEN @performance = 4 THEN 0.25
       WHEN @performance = 5 THEN 0.3
       ELSE 0
     END
  RETURN (@salary * @rate)
END
--------------------------------------------------------------
----CALL----
SELECT [dbo].[GetSalaryIncrement](32000, 1)
----------------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS dbo.GetIncrement;

CREATE PROCEDURE [dbo].[GetIncrement]
 @employeeId INT = 0 ,
 @performance INT = 1
AS
BEGIN
	 SET NOCOUNT ON

	 SELECT		FirstName,
				LastName,
				Salary,
				[dbo].[GetSalaryIncrement](Salary, @performance) AS Increment
	 FROM		Employee
	 WHERE		EmployeeId = IIF(@employeeId > 0, @employeeId, EmployeeId)
END
------------------------------------------------------------------
---CALLL--------------
EXECUTE GetIncrement
-------------------------------------------------------