USE [master]
GO
/****** Object:  Database [FinalAssignment]    Script Date: 9/7/2023 7:44:46 PM ******/
CREATE DATABASE [FinalAssignment]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FinalAssignment', FILENAME = N'C:\Users\krutika.rawal\FinalAssignment.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'FinalAssignment_log', FILENAME = N'C:\Users\krutika.rawal\FinalAssignment_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [FinalAssignment] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [FinalAssignment].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [FinalAssignment] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [FinalAssignment] SET ARITHABORT OFF 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [FinalAssignment] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [FinalAssignment] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [FinalAssignment] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [FinalAssignment] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [FinalAssignment] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [FinalAssignment] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [FinalAssignment] SET  ENABLE_BROKER 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [FinalAssignment] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [FinalAssignment] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [FinalAssignment] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [FinalAssignment] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [FinalAssignment] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [FinalAssignment] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [FinalAssignment] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [FinalAssignment] SET  MULTI_USER 
GO
ALTER DATABASE [FinalAssignment] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [FinalAssignment] SET DB_CHAINING OFF 
GO
ALTER DATABASE [FinalAssignment] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [FinalAssignment] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [FinalAssignment] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [FinalAssignment] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [FinalAssignment] SET QUERY_STORE = OFF
GO
USE [FinalAssignment]
GO
/****** Object:  UserDefinedFunction [dbo].[GetDeduction]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetDeduction]
(
 @EmployeeId INT
)
RETURNS DECIMAL (18,2)  
AS
BEGIN 
  DECLARE	@PF			DECIMAL(18,2) = 3.85,
			@Pension	DECIMAL(18,2) = 4.96,
			@Deduction	DECIMAL(18,2) = 4.96
  DECLARE	@Gross		DECIMAL(18,2) = (	SELECT GrossAmount  
											FROM Salary
											WHERE EmployeeId = @EmployeeId
										)
	SET		@Deduction =(( @Gross * @PF/100) + ( @Gross * @Pension/100 ))
  RETURN	@Deduction
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetSalary]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetSalary]
(
 @EmployeeId INT
)
RETURNS DECIMAL (18,2)  
AS
BEGIN 
  DECLARE	@PF			DECIMAL(18,2) = 3.85,
			@Pension	DECIMAL(18,2) = 4.96,
			@NetSalary	DECIMAL(18,2) = 4.96
  DECLARE	@Gross		DECIMAL(18,2) = (	SELECT GrossAmount  
											FROM Salary
											WHERE EmployeeId = @EmployeeId
										)
	SET @NetSalary =(@Gross -(( @Gross * @PF/100) + ( @Gross * @Pension/100 )))
  RETURN @NetSalary
END
GO
/****** Object:  Table [dbo].[Emplyoee]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Emplyoee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[DOB] [date] NULL,
	[Role] [varchar](50) NULL,
	[PharmacyId] [int] NULL,
	[JoiningDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PayementCode]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PayementCode](
	[PayementCodeId] [int] IDENTITY(1,1) NOT NULL,
	[PayementCode] [varchar](50) NULL,
	[DeductionRate] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[PayementCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaySlip]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaySlip](
	[PaySlipId] [int] IDENTITY(1,1) NOT NULL,
	[PayementCodeId] [int] NULL,
	[EmployeeId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[PaySlipId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Pharmacy]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Pharmacy](
	[PharmacyId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[Code] [varchar](50) NULL,
	[City] [varchar](50) NULL,
	[CreatedDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[PharmacyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Salary]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Salary](
	[SalaryId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NULL,
	[GrossAmount] [decimal](18, 2) NULL,
	[Deduction] [decimal](18, 2) NULL,
	[NetAmount] [decimal](18, 2) NULL,
	[SalaryDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[SalaryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Emplyoee] ON 
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (1, N'Priya', N'Bote', CAST(N'1996-11-10' AS Date), N'Manager', 1, CAST(N'2021-08-08' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (2, N'Rashi', N'Chopra', CAST(N'1995-07-02' AS Date), N'Employee', 1, CAST(N'2021-10-09' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (3, N'Karan', N'Sharma', CAST(N'1998-07-18' AS Date), N'Employee', 1, CAST(N'2022-12-10' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (4, N'Tanaya', N'Gavande', CAST(N'1997-01-05' AS Date), N'Manager', 2, CAST(N'2023-03-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (5, N'Seema', N'Wagh', CAST(N'1999-09-07' AS Date), N'Employee', 2, CAST(N'2023-08-06' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (6, N'Yash', N'Nand', CAST(N'1995-12-06' AS Date), N'Employee', 2, CAST(N'2023-06-04' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (7, N'Divya', N'Patil', CAST(N'2001-12-08' AS Date), N'Manager', 3, CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (8, N'Aashutosh', N'Rathod', CAST(N'2005-12-06' AS Date), N'Employee', 3, CAST(N'2023-10-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (9, N'Sangita', N'Maniyar', CAST(N'1993-05-02' AS Date), N'Employee', 3, CAST(N'2023-12-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (10, N'Soniya', N'Chaudhari', CAST(N'1997-10-08' AS Date), N'Manager', 4, CAST(N'2020-12-08' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (11, N'Prem', N'Sarvang', CAST(N'1998-05-07' AS Date), N'Employee', 4, CAST(N'2022-12-08' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (12, N'Kartik', N'Mehta', CAST(N'2000-07-07' AS Date), N'Employee', 4, CAST(N'2021-10-09' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (13, N'Prashant', N'Gaikwad', CAST(N'1998-04-03' AS Date), N'Manager', 5, CAST(N'2023-08-05' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (14, N'Gayatri', N'Jagtap', CAST(N'1997-01-09' AS Date), N'Employee', 5, CAST(N'2023-09-05' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (15, N'Kartik', N'Raghav', CAST(N'1993-07-08' AS Date), N'Employee', 5, CAST(N'2023-10-05' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (16, N'Swati', N'Desai', CAST(N'1998-07-07' AS Date), N'Manager', 6, CAST(N'2023-12-06' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (17, N'Vikram', N'Podar', CAST(N'1999-09-09' AS Date), N'Employee', 6, CAST(N'2023-12-08' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (18, N'Radhika', N'Pawar', CAST(N'2000-05-07' AS Date), N'Employee', 6, CAST(N'2023-12-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (19, N'Shivam', N'Rathod', CAST(N'1998-05-10' AS Date), N'Manager', 7, CAST(N'2023-12-06' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (20, N'Ragini', N'Shukla', CAST(N'1997-05-23' AS Date), N'Employee', 7, CAST(N'2023-12-11' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (21, N'Sanjay', N'Mehta', CAST(N'1992-07-19' AS Date), N'Employee', 7, CAST(N'2023-12-10' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (22, N'Bhushan', N'Gholap', CAST(N'1996-05-20' AS Date), N'Manager', 8, CAST(N'2020-01-05' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (23, N'Vaishali', N'Tidke', CAST(N'1999-07-17' AS Date), N'Employee', 8, CAST(N'2021-05-06' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (24, N'Priyanka', N'Borsate', CAST(N'2001-05-03' AS Date), N'Employee', 8, CAST(N'2022-05-07' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (25, N'Prathmesh', N'Shirsath', CAST(N'2001-11-13' AS Date), N'Manager', 9, CAST(N'2022-07-02' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (26, N'Shivani', N'Wagh', CAST(N'1998-12-15' AS Date), N'Employee', 9, CAST(N'2022-08-02' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (27, N'Neha', N'Wagh', CAST(N'1997-11-14' AS Date), N'Employee', 9, CAST(N'2022-09-02' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (28, N'Swaroop', N'Shinde', CAST(N'1997-11-17' AS Date), N'Manager', 10, CAST(N'2011-12-14' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (29, N'Deepak', N'Jha', CAST(N'1996-12-25' AS Date), N'Employee', 10, CAST(N'2012-12-14' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (30, N'Simran', N'Shivastav', CAST(N'1997-06-16' AS Date), N'Employee', 10, CAST(N'2013-12-14' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (31, N'Joy', N'Mathew', CAST(N'1997-07-19' AS Date), N'Manager', 11, CAST(N'2017-07-18' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (32, N'Roshni', N'Kelab', CAST(N'1993-08-16' AS Date), N'Employee', 11, CAST(N'2019-07-18' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (33, N'Serena', N'Gomez', CAST(N'1997-01-17' AS Date), N'Employee', 11, CAST(N'2020-07-18' AS Date))
GO
INSERT [dbo].[Emplyoee] ([EmployeeId], [FirstName], [LastName], [DOB], [Role], [PharmacyId], [JoiningDate]) VALUES (34, N'Justin', N'Bebier', CAST(N'1994-03-16' AS Date), N'Employee', 11, CAST(N'2021-07-18' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Emplyoee] OFF
GO
SET IDENTITY_INSERT [dbo].[PayementCode] ON 
GO
INSERT [dbo].[PayementCode] ([PayementCodeId], [PayementCode], [DeductionRate]) VALUES (1, N'BasicPay', CAST(0.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[PayementCode] ([PayementCodeId], [PayementCode], [DeductionRate]) VALUES (2, N'PF', CAST(3.85 AS Decimal(18, 2)))
GO
INSERT [dbo].[PayementCode] ([PayementCodeId], [PayementCode], [DeductionRate]) VALUES (3, N'Pension', CAST(4.96 AS Decimal(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[PayementCode] OFF
GO
SET IDENTITY_INSERT [dbo].[PaySlip] ON 
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (1, 1, 1)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (2, 2, 1)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (3, 3, 1)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (4, 1, 2)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (5, 2, 2)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (6, 3, 2)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (7, 1, 3)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (8, 2, 3)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (9, 3, 3)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (10, 1, 4)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (11, 2, 4)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (12, 3, 4)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (13, 1, 5)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (14, 2, 5)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (15, 3, 5)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (16, 1, 6)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (17, 2, 6)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (18, 3, 6)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (19, 1, 7)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (20, 2, 7)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (21, 3, 7)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (22, 1, 8)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (23, 2, 8)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (24, 3, 8)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (25, 1, 9)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (26, 2, 9)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (27, 3, 9)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (28, 1, 10)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (29, 2, 10)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (30, 3, 10)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (31, 1, 11)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (32, 2, 11)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (33, 3, 11)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (34, 1, 12)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (35, 2, 12)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (36, 3, 12)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (37, 1, 13)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (38, 2, 13)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (39, 3, 13)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (40, 1, 14)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (41, 2, 14)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (42, 3, 14)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (43, 1, 15)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (44, 2, 15)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (45, 3, 15)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (46, 1, 16)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (47, 2, 16)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (48, 3, 16)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (49, 1, 17)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (50, 2, 17)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (51, 3, 17)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (52, 1, 18)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (53, 2, 18)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (54, 3, 18)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (55, 1, 19)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (56, 2, 19)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (57, 3, 19)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (58, 1, 20)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (59, 2, 20)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (60, 3, 20)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (61, 1, 21)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (62, 2, 21)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (63, 3, 21)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (64, 1, 22)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (65, 2, 22)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (66, 3, 22)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (67, 1, 23)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (68, 2, 23)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (69, 3, 23)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (70, 1, 24)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (71, 2, 24)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (72, 3, 24)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (73, 1, 25)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (74, 2, 25)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (75, 3, 25)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (76, 1, 26)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (77, 2, 26)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (78, 3, 26)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (79, 1, 27)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (80, 2, 27)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (81, 3, 27)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (82, 1, 28)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (83, 2, 28)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (84, 3, 28)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (85, 1, 29)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (86, 2, 29)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (87, 3, 29)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (88, 1, 30)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (89, 2, 30)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (90, 3, 30)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (91, 1, 31)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (92, 2, 31)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (93, 3, 31)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (94, 1, 32)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (95, 2, 32)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (96, 3, 32)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (97, 1, 33)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (98, 2, 33)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (99, 3, 33)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (100, 1, 34)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (101, 2, 34)
GO
INSERT [dbo].[PaySlip] ([PaySlipId], [PayementCodeId], [EmployeeId]) VALUES (102, 3, 34)
GO
SET IDENTITY_INSERT [dbo].[PaySlip] OFF
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] ON 
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (1, N'Walgreens', N'P-2023-0001', N'Ahmedabad', CAST(N'2021-08-08' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (2, N'Heartland Pharmacy', N'P-2023-0002', N'Bangalore', CAST(N'2023-03-07' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (3, N'Rite Aid', N'P-2023-0003', N'Delhi', CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (4, N'CVS Pharmacy', N'P-2023-0004', N'Pune', CAST(N'2020-12-08' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (5, N'Omnicare', N'P-2023-0005', N'Mumbai', CAST(N'2023-08-05' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (6, N'Kings Pharmacy', N'P-2023-0006', N'Delhi', CAST(N'2023-12-06' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (7, N'Lifecare Pharmacy', N'P-2023-0007', N'Mumbai', CAST(N'2022-11-10' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (8, N'Pure Care Pharmacy', N'P-2023-0008', N'Bangalore', CAST(N'2020-01-05' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (9, N'Ryte Pharmacy', N'P-2023-0009', N'Ahmedabad', CAST(N'2022-07-02' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (10, N'Guardian pharmacy', N'P-2023-0010', N'Pune', CAST(N'2011-12-14' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (11, N'Prime Life Pharmacy', N'P-2023-0011', N'Delhi', CAST(N'2017-07-18' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] OFF
GO
SET IDENTITY_INSERT [dbo].[Salary] ON 
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (1, 1, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2021-09-08' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (2, 2, CAST(30000.00 AS Decimal(18, 2)), CAST(2643.00 AS Decimal(18, 2)), CAST(27357.00 AS Decimal(18, 2)), CAST(N'2021-11-09' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (3, 3, CAST(40000.00 AS Decimal(18, 2)), CAST(3524.00 AS Decimal(18, 2)), CAST(36476.00 AS Decimal(18, 2)), CAST(N'2023-01-10' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (4, 4, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2023-04-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (5, 5, CAST(45000.00 AS Decimal(18, 2)), CAST(3964.50 AS Decimal(18, 2)), CAST(41035.50 AS Decimal(18, 2)), CAST(N'2023-09-06' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (6, 6, CAST(35000.00 AS Decimal(18, 2)), CAST(3083.50 AS Decimal(18, 2)), CAST(31916.50 AS Decimal(18, 2)), CAST(N'2023-07-04' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (7, 7, CAST(55000.00 AS Decimal(18, 2)), CAST(4845.50 AS Decimal(18, 2)), CAST(50154.50 AS Decimal(18, 2)), CAST(N'2023-10-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (8, 8, CAST(40000.00 AS Decimal(18, 2)), CAST(3524.00 AS Decimal(18, 2)), CAST(36476.00 AS Decimal(18, 2)), CAST(N'2023-11-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (9, 9, CAST(37000.00 AS Decimal(18, 2)), CAST(3259.70 AS Decimal(18, 2)), CAST(33740.30 AS Decimal(18, 2)), CAST(N'2024-01-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (10, 10, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2021-01-08' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (11, 11, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2023-01-08' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (12, 12, CAST(25000.00 AS Decimal(18, 2)), CAST(2202.50 AS Decimal(18, 2)), CAST(22797.50 AS Decimal(18, 2)), CAST(N'2021-11-09' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (13, 13, CAST(70000.00 AS Decimal(18, 2)), CAST(6167.00 AS Decimal(18, 2)), CAST(63833.00 AS Decimal(18, 2)), CAST(N'2023-09-05' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (14, 14, CAST(60000.00 AS Decimal(18, 2)), CAST(5286.00 AS Decimal(18, 2)), CAST(54714.00 AS Decimal(18, 2)), CAST(N'2023-10-05' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (15, 15, CAST(45000.00 AS Decimal(18, 2)), CAST(3964.50 AS Decimal(18, 2)), CAST(41035.50 AS Decimal(18, 2)), CAST(N'2023-11-05' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (16, 16, CAST(80000.00 AS Decimal(18, 2)), CAST(7048.00 AS Decimal(18, 2)), CAST(72952.00 AS Decimal(18, 2)), CAST(N'2024-01-06' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (17, 17, CAST(40000.00 AS Decimal(18, 2)), CAST(3524.00 AS Decimal(18, 2)), CAST(36476.00 AS Decimal(18, 2)), CAST(N'2024-01-08' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (18, 18, CAST(40000.00 AS Decimal(18, 2)), CAST(3524.00 AS Decimal(18, 2)), CAST(36476.00 AS Decimal(18, 2)), CAST(N'2024-01-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (19, 19, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2024-01-06' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (20, 20, CAST(45000.00 AS Decimal(18, 2)), CAST(3964.50 AS Decimal(18, 2)), CAST(41035.50 AS Decimal(18, 2)), CAST(N'2024-01-11' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (21, 21, CAST(25000.00 AS Decimal(18, 2)), CAST(2202.50 AS Decimal(18, 2)), CAST(22797.50 AS Decimal(18, 2)), CAST(N'2024-01-10' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (22, 22, CAST(55000.00 AS Decimal(18, 2)), CAST(4845.50 AS Decimal(18, 2)), CAST(50154.50 AS Decimal(18, 2)), CAST(N'2021-06-06' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (23, 23, CAST(35000.00 AS Decimal(18, 2)), CAST(3083.50 AS Decimal(18, 2)), CAST(31916.50 AS Decimal(18, 2)), CAST(N'2022-06-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (24, 24, CAST(36000.00 AS Decimal(18, 2)), CAST(3171.60 AS Decimal(18, 2)), CAST(32828.40 AS Decimal(18, 2)), CAST(N'2022-08-02' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (25, 25, CAST(50000.00 AS Decimal(18, 2)), CAST(4405.00 AS Decimal(18, 2)), CAST(45595.00 AS Decimal(18, 2)), CAST(N'2022-09-02' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (26, 26, CAST(30000.00 AS Decimal(18, 2)), CAST(2643.00 AS Decimal(18, 2)), CAST(27357.00 AS Decimal(18, 2)), CAST(N'2022-10-02' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (27, 27, CAST(28000.00 AS Decimal(18, 2)), CAST(2466.80 AS Decimal(18, 2)), CAST(25533.20 AS Decimal(18, 2)), CAST(N'2012-01-14' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (28, 28, CAST(55000.00 AS Decimal(18, 2)), CAST(4845.50 AS Decimal(18, 2)), CAST(50154.50 AS Decimal(18, 2)), CAST(N'2013-01-14' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (29, 29, CAST(45000.00 AS Decimal(18, 2)), CAST(3964.50 AS Decimal(18, 2)), CAST(41035.50 AS Decimal(18, 2)), CAST(N'2014-01-14' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (30, 30, CAST(39000.00 AS Decimal(18, 2)), CAST(3435.90 AS Decimal(18, 2)), CAST(35564.10 AS Decimal(18, 2)), CAST(N'2017-09-18' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (31, 31, CAST(49000.00 AS Decimal(18, 2)), CAST(4316.90 AS Decimal(18, 2)), CAST(44683.10 AS Decimal(18, 2)), CAST(N'2019-08-18' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (32, 32, CAST(25000.00 AS Decimal(18, 2)), CAST(2202.50 AS Decimal(18, 2)), CAST(22797.50 AS Decimal(18, 2)), CAST(N'2020-08-18' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (33, 33, CAST(25000.00 AS Decimal(18, 2)), CAST(2202.50 AS Decimal(18, 2)), CAST(22797.50 AS Decimal(18, 2)), CAST(N'2021-08-18' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (34, 34, CAST(25000.00 AS Decimal(18, 2)), CAST(2202.50 AS Decimal(18, 2)), CAST(22797.50 AS Decimal(18, 2)), CAST(N'2021-08-18' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Salary] OFF
GO
ALTER TABLE [dbo].[Emplyoee]  WITH CHECK ADD FOREIGN KEY([PharmacyId])
REFERENCES [dbo].[Pharmacy] ([PharmacyId])
GO
ALTER TABLE [dbo].[PaySlip]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Emplyoee] ([EmployeeId])
GO
ALTER TABLE [dbo].[PaySlip]  WITH CHECK ADD FOREIGN KEY([PayementCodeId])
REFERENCES [dbo].[PayementCode] ([PayementCodeId])
GO
ALTER TABLE [dbo].[Salary]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Emplyoee] ([EmployeeId])
GO
/****** Object:  StoredProcedure [dbo].[GetDetails]    Script Date: 9/7/2023 7:44:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetDetails]
@case INT = 0
AS 
BEGIN
	IF (@case= 1)
		BEGIN
			UPDATE	Salary
			SET		Deduction = (SELECT [dbo].[GetDeduction] (EmployeeID)),
					NetAmount = (SELECT [dbo].[GetSalary] (EmployeeID))
			WHERE	EmployeeId = EmployeeId

			SELECT	EmployeeId,
					GrossAmount,
					Deduction,
					NetAmount		
			FROM	Salary
		END
	IF	(@case = 2)
		BEGIN
				SELECT		P.[Name] AS PharmacyName,
							CONCAT (Emp.FirstName,' ', Emp.LastName) AS EmplyoeeName, 
							Emp.DOB, 
							Emp.[Role]  
				FROM		Pharmacy P
				INNER JOIN	Emplyoee AS Emp
				ON			P.PharmacyId = Emp.PharmacyId
		END
	IF (@case = 3)
		begin
				SELECT		P.[Name],
							MIN(Sal.GrossAmount) AS MinimumSalary
				FROM		Pharmacy P
							INNER JOIN	Emplyoee AS Emp ON	P.PharmacyId = Emp.PharmacyId
				            INNER JOIN	Salary	Sal ON	Sal.EmployeeId = Emp.EmployeeId
				GROUP BY	P.[Name]
		end

END
GO
USE [master]
GO
ALTER DATABASE [FinalAssignment] SET  READ_WRITE 
GO
