--CREATE DATABASE FinalAssignment
--USE	FinalAssignment
DROP TABLE IF EXISTS Salary, PaySlip, PayementCode, Emplyoee, Pharmacy


--CREATE TABLE Pharmacy
CREATE TABLE Pharmacy	(
							PharmacyId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]		VARCHAR(50),
							Code		VARCHAR(50),
							City		VARCHAR(50),
							CreatedDate	DATE
						)

--INSERT RECORDS
INSERT INTO Pharmacy	([Name], Code, City, CreatedDate)	VALUES
						('Walgreens', 'P-2023-0001', 'Ahmedabad', '2021-08-08'),
						('Heartland Pharmacy', 'P-2023-0002', 'Bangalore', '2023-03-07'),
						('Rite Aid', 'P-2023-0003', 'Delhi', '2023-09-07'),
						('CVS Pharmacy', 'P-2023-0004', 'Pune', '2020-12-08'),
						('Omnicare', 'P-2023-0005', 'Mumbai', '2023-08-05'),
						('Kings Pharmacy', 'P-2023-0006', 'Delhi', '2023-12-06'),
						('Lifecare Pharmacy', 'P-2023-0007', 'Mumbai', '2022-11-10'),
						('Pure Care Pharmacy', 'P-2023-0008', 'Bangalore', '2020-01-05'),
						('Ryte Pharmacy', 'P-2023-0009', 'Ahmedabad', '2022-07-02'),
						('Guardian pharmacy', 'P-2023-0010', 'Pune', '2011-12-14'),
						('Prime Life Pharmacy', 'P-2023-0011', 'Delhi', '2017-07-18')

SELECT	PharmacyId,
		[Name] AS PharmacyName,
		Code,
		City,
		CreatedDate
FROM	Pharmacy
------------------------------------------------------------------------------------------------
--CREATE TABLE EMPLOYEE
CREATE TABLE Emplyoee	(
							EmployeeId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							FirstName	VARCHAR(50),
							LastName	VARCHAR(50),
							DOB			DATE,
							[Role]		VARCHAR(50),
							PharmacyId	INT	FOREIGN KEY REFERENCES Pharmacy(PharmacyId),
							JoiningDate	DATE
						)

--INSERT RECORDS
INSERT INTO Emplyoee	(FirstName, LastName, DOB, [Role], PharmacyId, JoiningDate) VALUES
						('Priya', 'Bote', '1996-11-10', 'Manager',1 , '2021-08-08'),
						('Rashi', 'Chopra', '1995-07-02', 'Employee',1 , '2021-10-09'),
						('Karan', 'Sharma', '1998-07-18', 'Employee', 1, '2022-12-10'),
						('Tanaya', 'Gavande', '1997-01-05', 'Manager', 2, '2023-03-07'),
						('Seema', 'Wagh', '1999-09-07', 'Employee',2 , '2023-08-06'),
						('Yash', 'Nand', '1995-12-06', 'Employee',2 , '2023-06-04'),
						('Divya', 'Patil','2001-12-08', 'Manager',3 , '2023-09-07'),
						('Aashutosh', 'Rathod', '2005-12-06', 'Employee',3 , '2023-10-07'),
						('Sangita', 'Maniyar', '1993-05-02', 'Employee', 3, '2023-12-07'),
						('Soniya', 'Chaudhari', '1997-10-08', 'Manager',4 , '2020-12-08'),
						('Prem', 'Sarvang', '1998-05-07', 'Employee',4 , '2022-12-08'),
						('Kartik', 'Mehta', '2000-07-07', 'Employee',4 , '2021-10-09'),
						('Prashant', 'Gaikwad', '1998-04-03', 'Manager',5 , '2023-08-05'),
						('Gayatri', 'Jagtap', '1997-01-09', 'Employee',5 , '2023-09-05'),
						('Kartik', 'Raghav', '1993-07-08', 'Employee',5 , '2023-10-05'),
						('Swati', 'Desai', '1998-07-07', 'Manager', 6, '2023-12-06'),
						('Vikram', 'Podar', '1999-09-09', 'Employee',6 , '2023-12-08'),
						('Radhika', 'Pawar', '2000-05-07', 'Employee',6 , '2023-12-07'),
						('Shivam', 'Rathod', '1998-05-10', 'Manager',7 , '2023-12-06'),
						('Ragini', 'Shukla', '1997-05-23', 'Employee',7 , '2023-12-11'),
						('Sanjay', 'Mehta', '1992-07-19', 'Employee',7 , '2023-12-10'),
						('Bhushan', 'Gholap', '1996-05-20', 'Manager',8 , '2020-01-05'),
						('Vaishali', 'Tidke', '1999-07-17', 'Employee', 8, '2021-05-06'),
						('Priyanka', 'Borsate', '2001-05-03', 'Employee',8 , '2022-05-07'),
						('Prathmesh', 'Shirsath', '2001-11-13', 'Manager',9 , '2022-07-02'),
						('Shivani', 'Wagh', '1998-12-15', 'Employee',9 , '2022-08-02'),
						('Neha', 'Wagh', '1997-11-14', 'Employee',9 , '2022-09-02'),
						('Swaroop', 'Shinde', '1997-11-17', 'Manager',10 , '2011-12-14'),
						('Deepak', 'Jha', '1996-12-25', 'Employee',10 , '2012-12-14'),
						('Simran', 'Shivastav', '1997-06-16', 'Employee',10 , '2013-12-14'),
						('Joy', 'Mathew', '1997-07-19', 'Manager',11 , '2017-07-18'),
						('Roshni', 'Kelab', '1993-08-16', 'Employee', 11, '2019-07-18'),
						('Serena', 'Gomez', '1997-01-17', 'Employee',11 , '2020-07-18'),
						('Justin', 'Bebier', '1994-03-16', 'Employee', 11, '2021-07-18')

--SELECT QUERY
SELECT	EmployeeId,
		CONCAT (FirstName,' ', LastName) AS Name, 
		DOB, 
		[Role], 
		PharmacyId, 
		JoiningDate
FROM	Emplyoee
--------------------------------------------------------------------------------------------------------
--CREATE TABLE PAYEMENTCODE
CREATE TABLE PayementCode	(
								PayementCodeId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
								PayementCode	VARCHAR(50),
								DeductionRate	DECIMAL(18,2)
							)

--INSERT RECORDS
INSERT INTO PayementCode	(PayementCode, DeductionRate)	VALUES
							('BasicPay',0 ),
							('PF',3.85 ),
							('Pension',4.96)

--SELECT QUERY
SELECT	PayementCodeId,
		PayementCode, 
		DeductionRate
FROM	PayementCode

---------------------------------------------------------------------------------------------------------
--CREATE TABLE PAYSLIP
CREATE TABLE PaySlip	(
							PaySlipId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							PayementCodeId	INT FOREIGN KEY REFERENCES PayementCode(PayementCodeId),
							EmployeeId		INT FOREIGN KEY REFERENCES Emplyoee(EmployeeId)
						)

--INSERT RECORDS
INSERT INTO PaySlip		(PayementCodeId,EmployeeId)	VALUES
						(1,1),
						(2,1),
						(3,1),
						(1,2),
						(2,2),
						(3,2),
						(1,3),
						(2,3),
						(3,3),
						(1,4),
						(2,4),
						(3,4),
						(1,5),
						(2,5),
						(3,5),
						(1,6),
						(2,6),
						(3,6),
						(1,7),
						(2,7),
						(3,7),
						(1,8),
						(2,8),
						(3,8),
						(1,9),
						(2,9),
						(3,9),
						(1,10),
						(2,10),
						(3,10),
						(1,11),
						(2,11),
						(3,11),
						(1,12),
						(2,12),
						(3,12),
						(1,13),
						(2,13),
						(3,13),
						(1,14),
						(2,14),
						(3,14),
						(1,15),
						(2,15),
						(3,15),
						(1,16),
						(2,16),
						(3,16),
						(1,17),
						(2,17),
						(3,17),
						(1,18),
						(2,18),
						(3,18),
						(1,19),
						(2,19),
						(3,19),
						(1,20),
						(2,20),
						(3,20),
						(1,21),
						(2,21),
						(3,21),
						(1,22),
						(2,22),
						(3,22),
						(1,23),
						(2,23),
						(3,23),
						(1,24),
						(2,24),
						(3,24),
						(1,25),
						(2,25),
						(3,25),
						(1,26),
						(2,26),
						(3,26),
						(1,27),
						(2,27),
						(3,27),
						(1,28),
						(2,28),
						(3,28),
						(1,29),
						(2,29),
						(3,29),
						(1,30),
						(2,30),
						(3,30),
						(1,31),
						(2,31),
						(3,31),
						(1,32),
						(2,32),
						(3,32),
						(1,33),
						(2,33),
						(3,33),
						(1,34),
						(2,34),
						(3,34)

--SELECT QUERY
SELECT	PaySlipId,
		PayementCodeId,
		EmployeeId
FROM	PaySlip
------------------------------------------------------------------------------------------------
--CREATE TABLE SALARY
CREATE TABLE Salary		(
							SalaryId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							EmployeeId  INT FOREIGN KEY REFERENCES Emplyoee(EmployeeId),
							GrossAmount	DECIMAL(18,2),
							Deduction	DECIMAL(18,2),
							NetAmount	DECIMAL(18,2),
							SalaryDate	DATE
						)

--INSERT RECORDS
INSERT INTO Salary	(EmployeeId , GrossAmount, SalaryDate) VALUES
					(1,50000 , '2021-09-08'),
					(2,30000 , '2021-11-09'),
					(3,40000 , '2023-01-10'),
					(4, 50000, '2023-04-07'),
					(5,45000 , '2023-09-06'),
					(6, 35000, '2023-07-04'),
					(7,55000 , '2023-10-07'),
					(8,40000 , '2023-11-07'),
					(9, 37000, '2024-01-07'),
					(10, 50000, '2021-01-08'),
					(11, 50000, '2023-01-08'),
					(12, 25000, '2021-11-09'),
					(13, 70000, '2023-09-05'),
					(14, 60000, '2023-10-05'),
					(15,45000 , '2023-11-05'),
					(16, 80000, '2024-01-06'),
					(17, 40000, '2024-01-08'),
					(18, 40000, '2024-01-07'),
					(19, 50000, '2024-01-06'),
					(20, 45000, '2024-01-11'),
					(21, 25000, '2024-01-10'),
					(22, 55000, '2021-06-06'),
					(23, 35000, '2022-06-07'),
					(24, 36000, '2022-08-02'),
					(25, 50000, '2022-09-02'),
					(26, 30000, '2022-10-02'),
					(27, 28000, '2012-01-14'),
					(28, 55000, '2013-01-14'),
					(29, 45000, '2014-01-14'),
					(30, 39000, '2017-09-18'),
					(31, 49000, '2019-08-18'),
					(32, 25000, '2020-08-18'),
					(33, 25000, '2021-08-18'),
					(34, 25000, '2021-08-18')
					
--SELECT QUERY
SELECT	SalaryId,	
		EmployeeId , 
		GrossAmount,
		Deduction,	
		NetAmount,	
		SalaryDate
FROM	Salary	
-------------------------------------------------------------------------------------------------
--CREATE FUNCTION GetTotalAmount
DROP FUNCTION IF EXISTS [dbo].[GetSalary]
CREATE FUNCTION [dbo].[GetSalary]
(
 @EmployeeId INT
)
RETURNS DECIMAL (18,2)  
AS
BEGIN 
  DECLARE	@PF			DECIMAL(18,2) = 3.85,
			@Pension	DECIMAL(18,2) = 4.96,
			@NetSalary	DECIMAL(18,2) = 4.96
  DECLARE	@Gross		DECIMAL(18,2) = (	SELECT GrossAmount  
											FROM Salary
											WHERE EmployeeId = @EmployeeId
										)
	SET @NetSalary =(@Gross -(( @Gross * @PF/100) + ( @Gross * @Pension/100 )))
  RETURN @NetSalary
END
--------------------------------------------------------------------------------------------
DROP FUNCTION IF EXISTS [dbo].[GetDeduction]
CREATE FUNCTION [dbo].[GetDeduction]
(
 @EmployeeId INT
)
RETURNS DECIMAL (18,2)  
AS
BEGIN 
  DECLARE	@PF			DECIMAL(18,2) = 3.85,
			@Pension	DECIMAL(18,2) = 4.96,
			@Deduction	DECIMAL(18,2) = 4.96
  DECLARE	@Gross		DECIMAL(18,2) = (	SELECT GrossAmount  
											FROM Salary
											WHERE EmployeeId = @EmployeeId
										)
	SET		@Deduction =(( @Gross * @PF/100) + ( @Gross * @Pension/100 ))
  RETURN	@Deduction
END
-------------------------------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS [dbo].[GetDetails]
alter PROCEDURE [dbo].[GetDetails]
@case INT = 0
AS 
BEGIN
	IF (@case= 1)
		BEGIN
			UPDATE	Salary
			SET		Deduction = (SELECT [dbo].[GetDeduction] (EmployeeID)),
					NetAmount = (SELECT [dbo].[GetSalary] (EmployeeID))
			WHERE	EmployeeId = EmployeeId

			SELECT	EmployeeId,
					GrossAmount,
					Deduction,
					NetAmount		
			FROM	Salary
		END
	IF	(@case = 2)
		BEGIN
				SELECT		P.[Name] AS PharmacyName,
							CONCAT (Emp.FirstName,' ', Emp.LastName) AS EmplyoeeName, 
							Emp.DOB, 
							Emp.[Role]  
				FROM		Pharmacy P
				INNER JOIN	Emplyoee AS Emp
				ON			P.PharmacyId = Emp.PharmacyId
		END
	IF (@case = 3)
		begin
				SELECT		P.[Name],
							MIN(Sal.GrossAmount) AS MinimumSalary
				FROM		Pharmacy P
							INNER JOIN	Emplyoee AS Emp ON	P.PharmacyId = Emp.PharmacyId
				            INNER JOIN	Salary	Sal ON	Sal.EmployeeId = Emp.EmployeeId
				GROUP BY	P.[Name]
		end

END
EXECUTE [dbo].[GetDetails] 2
SELECT *FROM Salary

				--;WITH LowestSalaryPerPharmacy AS
				--(
				--	SELECT		P.[Name],
				--				MIN(Sal.GrossAmount) AS MinimumSalary
				--	FROM		Pharmacy P
				--	INNER JOIN	Emplyoee AS Emp ON	P.PharmacyId = Emp.PharmacyId
				--    INNER JOIN	Salary	Sal ON	Sal.EmployeeId = Emp.EmployeeId
				--	GROUP BY	P.[Name]
				--)
				--SELECT * FROM LowestSalaryPerPharmacy
				
				--LowestSalaryEmployee AS 
				--(
				--	SELECT
				--				P.[Name],
				--				CONCAT (Emp.FirstName,' ', Emp.LastName) AS Name,
				--	FROM		Pharmacy P
				--	INNER JOIN	Emplyoee AS Emp ON	P.PharmacyId =	Emp.PharmacyId
				--	INNER JOIN	Salary AS	Sal ON		Sal.EmployeeId =	Emp.EmployeeId
				--	INNER JOIN  LowestSalaryPerPharmacy AS lsp ON P.[Name] = lsp.[Name]
				--	WHERE		Sal.GrossAmount = lsp.MinimumSalary
				--)
				--SELECT * FROM LowestSalaryEmployee 

				--SELECT		P.[Name],
				--			lse.FirstName,
				--			lse.LastName,
				--			lsp.MinimumSalary
				--FROM		Pharmacy P
				--LEFT JOIN	LowestSalaryEmployee lse ON  P.[Name] =	lse.[Name]
				--LEFT JOIN	LowestSalaryPerPharmacy lsp ON P.[Name] = lsp.[Name]
			
			

	--SELECT 	CONCAT (FirstName,' ', LastName) AS EmpName 
	--from	Emplyoee	
	--WHERE	EmployeeId IN
	--	(
	--		SELECT		P.[Name],
	--							MIN(Sal.GrossAmount) AS MinimumSalary
	--				FROM		Pharmacy P
	--							INNER JOIN	Emplyoee AS Emp ON	P.PharmacyId = Emp.PharmacyId
	--							INNER JOIN	Salary	Sal ON	Sal.EmployeeId = Emp.EmployeeId
	--				GROUP BY	P.[Name]
		
	--	)