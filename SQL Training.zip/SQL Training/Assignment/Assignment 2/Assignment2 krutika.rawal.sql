﻿--Training Assignment 2

--USE master
--DROP DATABASE IF EXISTS HospitalSystem
--CREATE DATABASE HospitalSystem
--USE HospitalSystem

--DROP TABLE
DROP TABLE IF EXISTS Hospital, Patient,  Appointment

SET NOCOUNT ON
--UNDERSTANDING DATATYPES
DECLARE	@a VARCHAR(50)
SELECT	@a='ADITIYA'
PRINT	@a

DECLARE	@b INT = 101
PRINT @b

DECLARE @c BIT= 'TRUE'
PRINT	@c

DECLARE	@DATE DATETIME
SET @DATE = GETDATE() 
PRINT @DATE

DECLARE @num DECIMAL(20,2) = '98312678.669';
PRINT @num

--CREATE TABLE Hospital
CREATE TABLE Hospital(	HospitalId	 INT,
						HospitalName VARCHAR(50),
						Accredation	 VARCHAR(50),
						Speciality	 VARCHAR( 50),
						City		 VARCHAR( 50),
						Beds		 INT,
						Department	 INT 
				     )

--ALTER TABLE
ALTER TABLE Hospital ALTER COLUMN HospitalId VARCHAR( 50)
--INSERT TABLE
INSERT INTO Hospital VALUES	('H-2006-0001','Sterling Hospitals','AAC','cardiology ,neurology','Ahmedabad',3000,10),
							('H-2006-0002 ','Ruby Hall Clinic','NABH','multi-speciality centre','Pune',2000,15),
							('H-2006-0003 ','Sparsh Hospital','NABH','Bone Marrow Transplant, Dermatology','Bangalore',5000,9),
							('H-2006-0004 ','Baby Memorial Hospital','NABL',' Gynaecology ',' Calicut',3000,5),
							('H-2006-0005  ','Escorts Heart Institute & Research Centre','AAC','Neurology','Pune',7000,15),
							('H-2006-0006 ','Apllo Hospital','AAC',' Pulmonology','Pune',3000,20),
							('H-2006-0007 ','JaiRam Hospital','NABH','‎Obstetrics','Delhi',5000,10)

--SELECT QUERY
SELECT * FROM Hospital

--CREATE TABLE Patient
CREATE TABLE Patient	(	PatientId VARCHAR(50),
							[Name]	VARCHAR(50),
							PhoneNo	VARCHAR(20),
							Age	INT,
							Gender	VARCHAR(30),
							AttendingDr VARCHAR(50),
							Disease	VARCHAR(50),
							AppointmentId VARCHAR(50)
						)
--INSERT TABLE
INSERT INTO Patient VALUES	('P-2023-0001','Aashutosh Rathod','8897456687',40,'male','Dr.Peter','Fracture','AP-2023-0011'),
							('P-2023-0002',	'Sangita Maniyar','7410258987',	36	,'female','Dr.Alvani','Diabetes','AP-2023-0012'),
							('P-2023-0003',	'Soniya Chaudhari','9875641230',45,'female','Dr.Kanuajia','Brain Tumor','AP-2023-0013'),
							('P-2023-0004','Prem Sarvang','9874512630',30,'male','Dr.Kanuajia','Mental Stress','AP-2023-0014'),
							('P-2023-0005',	'Kartik Mehta',	'8897456688',55,'male',	'Dr.Alvani','High Blood Pressure','AP-2023-0015')

--SELECT QUERY
SELECT * FROM Patient

--CREATE TABLE Appointment 
CREATE TABLE Appointment (	AppointmentId VARCHAR(50),
							StartDateTime DATETIME,
							EndDateTime DATETIME,
							AttendingDr VARCHAR(50),
							PatientId VARCHAR(50),
							HospitalId VARCHAR(50)
						)

--INSERT TABLE
INSERT INTO Appointment VALUES('AP-2023-0011','2021-08-08 17:08:52', '2021-08-08 17:15:52' ,'Dr.Peter','P-2023-0001',	'H-2006-0002'),
							  ('AP-2023-0012',	'2023-03-07 15:08:52' ,'2023-03-07 15:30:52', 'Dr.Alvani','P-2023-0002','H-2006-0002'),
							  ('AP-2023-0013', '2023-09-07 16:06:52' ,'2023-09-07 16:20:52' ,'Dr.Kanuajia',	'P-2023-0003','H-2006-0002'),
							  ('AP-2023-0014',	'2020-12-08 18:08:52' ,'2020-12-08 18:10:52' ,'Dr.Kanuajia','P-2023-0004','H-2006-0002'),
							  ('AP-2023-0015',	'2023-08-05 11:08:52' ,	'2023-08-05 11:30:52' ,	'Dr.Alvani'	,'P-2023-0005','H-2006-0002 ')
--SELECT Query
SELECT * FROM  Appointment



						

							





	
