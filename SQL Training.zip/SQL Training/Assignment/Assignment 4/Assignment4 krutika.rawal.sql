--CREATE DATABASE Practice
--USE Practice
SET NOCOUNT ON
DROP TABLE IF EXISTS Employee, Students, Teachers,  Departments

--CREATE TABLE
CREATE TABLE Employee
(
	EmployeeId	INT,
	FirstName	VARCHAR(50),
	LastName	VARCHAR(50),
	CompanyID	INT,
	Salary		DECIMAL(18,2)
)

INSERT INTO Employee VALUES
(1, 'Prathamesh', 'Shirsath', 1, 32000),
(2, 'Riya', 'Bachav', 2, 45000),
(3, 'Tanaya', 'Gavande', 3,42000),
(4, 'Anuja','Mehta',1,32000),
(5, 'Sagar', 'Vasu', 2, 45000),
(6, 'Seema', 'Shastri',3, 40000),
(7, 'Raghav', 'Bachav',2, 45000),
(8, 'Kimaya', 'Podar',1,44000),
(9, 'Sanjay', 'Mehta', 3, 42000),
(10, 'Radhika', 'Patil', 1, 42000),
(11, 'Krishna', 'Rathod', 4, 50000),
(12, 'Priyaka', 'Roy', 4, 42000)

--SELECT * FROM Employee

--GROUP BY
SELECT		CompanyId,
COUNT		(EmployeeId) AS	TotalEmp
FROM		Employee
GROUP BY	CompanyID

SELECT		CompanyID,
MAX			(Salary)	AS TotalSalary
FROM		Employee
GROUP BY	CompanyID

SELECT		CompanyID,
MIN			(Salary)	AS TotalSalary
FROM		Employee
GROUP BY	CompanyID

SELECT		CompanyID,
AVG			(Salary)	AS TotalSalary
FROM		Employee
GROUP BY	CompanyID

SELECT		CompanyID,
SUM			(Salary)	AS TotalSalary
FROM		Employee
GROUP BY	CompanyID

SELECT		LastName,
COUNT		(EmployeeId) AS TotalEmp
FROM		Employee
GROUP BY	LastName	

--HAVING
SELECT		CompanyId,
COUNT		(EmployeeId)	AS TotalEmployee
FROM		Employee
GROUP BY	CompanyId
HAVING		COUNT(EmployeeId) > 2

SELECT		CompanyId,
COUNT		(Salary)	AS Salary
FROM		Employee
GROUP BY	CompanyId
HAVING		MAX(Salary) >=45000

SELECT		CompanyId, FirstName,
COUNT		(Salary)	AS Salary
FROM		Employee
GROUP BY	CompanyId, FirstName
HAVING		MIN(Salary) <= 40000

--CREATE TABLE
CREATE TABLE Departments(	DepartmentID	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							HOD				VARCHAR(50),
							StaffCount		INT,
							Code			INT
						)

--INSERT TABLE	
INSERT INTO Departments ([Name],HOD,StaffCount,Code) VALUES	('ENTC','Prashant Gaikwad',10,0001),
															('Computer','Gayatri Jagtap',15,0002),
															('Mechanical','Kartik Raghav',16,0003),
															('IT','Swati Desai',10,0004),
															('Electrical','Vikram Podar',12,0005)


--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY DepartmentID) AS SrNo,
		DepartmentID,
		[Name] AS DepartmentName,
		HOD,
		StaffCount,
		Code
FROM	Departments

--CREATE TABLE
CREATE TABLE Teachers	(	TeacherId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							Specialization	VARCHAR(50),
							PhoneNo			VARCHAR(30),
							Age				INT,
							City			VARCHAR(30),
							Salary			DECIMAL(18,2),
							DepartmentId	INT FOREIGN KEY REFERENCES Departments(DepartmentId)
						)

--INSERT TABLE
INSERT INTO Teachers	([Name], Specialization, PhoneNo, Age, City,Salary, DepartmentId) VALUES 
						('Radhika Pawar', 'CyberSecurity', '9874152630', 35, 'Pune',45000, 4),
						('Shivam Rathod', 'MachineDesign', '8874152030', 40, 'nsk',40000, 3),
						('Ragini Shukla', 'ArtificialIntelligence', '9872563014',  37,'Mumbai',35000, 2),
						('Sanjay Mehta', ' EmbeddedSystems', '9748562103', 40, 'nsk',40000, 1),
						('Bhushan Gholap', 'SoftwareTesting', '8874599632', 39, 'nsk',39000, 2),
						('Vaishali Tidke', 'PowerEngineering', '7784455921', 37, 'Delhi',42000, 5),
						('Priyanka Borsate', 'Blockchain', '9847510220', 30, 'Pune',46000, 4),
						('Prathmesh Shirsath', 'DataScience', '9744885120', 35, 'Mumbai',40000, 2),
						('Shivani Wagh', 'ArtificialIntelligence','9992514000', 32, 'Mumbai',25000, 2),
						('Neha Wagh', 'SoftwareTesting','9977885541', 31,  'Pune',30000,4),
						('Swaroop Shinde','EmbeddedSystems','7844551020', 35, 'nsk',45000, 1)

--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY TeacherID) AS SrNo,
		[Name] AS TeacherName, 
		Specialization, 
		PhoneNo,
		Age,
		City,
		Salary,
		DepartmentId
FROM	Teachers

--CREATE TABLE
CREATE TABLE Students	(	StudentId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							Age				INT,
							Gender			VARCHAR(50),
							PhoneNo			VARCHAR(30),
							DepartmentId	INT FOREIGN KEY REFERENCES Departments(DepartmentId)
						)

--INSERT TABLE
INSERT INTO Students	([Name], Age, Gender, PhoneNo, DepartmentId) VALUES
						('Priya Bote', 21, 'Female', '7788445963', 2),
						('Karan Sharma', 22, 'Male', '9784512633', 3),
						('Rashi Chopra', 21, 'Female', '9588747114', 5),
						('Yash Raghuvanshi', 23, 'Male', '7488559661', 3),
						('Seema Nand', 24, 'Female', '8874112256',4),
						('Divya Patil', 22, 'Female', '9874455621', 1),
						('Kiran Bendkoli', 23, 'Male', '9228774563',5),
						('Tanaya Gavande',21, 'Female', '9598774632', 2),
						('Apurva Jadhav',22, 'Female', '7411528220',4),
						('Kamini Yadav', 22, 'Female', '9588747114', 5),
						('Shivam Bhat', 23, 'Male', '9588747144', 5)


--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY StudentId) AS SrNo,
		[Name] AS StudentName, 
		Age, 
		Gender, 
		PhoneNo, 
		DepartmentId
FROM    Students

-- a) USING # LOCAL TEMPORARY TABLE
DROP TABLE IF EXISTS #Books

CREATE TABLE #Books
(
	BookId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[Name]		VARCHAR(50),
	Publication	VARCHAR(50)
)

INSERT INTO #Books  VALUES
	('AI','TECH-MAX'),
	('Blockchain','TECH-NEO'),
	('DBMS', 'TECH-MAX'),
	('SPOS','TECH-MAX')

SELECT	BookId, 
		[Name]	AS BookName,
		Publication
FROM	#Books

-- b) USING @ LOCAL TEMPORARY TABLE

DECLARE @Employee AS TABLE
(
   EmployeeId  INT,
   EmplyeeName  VARCHAR(50)
)

SELECT  EmployeeId,
		EmplyeeName
FROM	@Employee

-- C) USING SELECT LOCAL TEMPORARY TABLE
DROP TABLE 	IF EXISTS #Emp
SELECT	StudentId,
		[Name] AS StudentName,
		Age,	
		DepartmentId
INTO	#Emp
FROM	Students

SELECT	StudentId,
		StudentName,
		Age,	
		DepartmentId
FROM	#Emp

-- d) USING CTE (COMMON TABLE EXPRESSION)

SELECT * FROM Teachers
-- IDENTIFY SECOND HIGHEST SALARY (DYNAMICALLY) OF TEACHER ON THE BASIS OF DEPARTMENT
;WITH SecondHighest AS 
(
SELECT ROW_NUMBER() OVER (PARTITION BY DepartmentId ORDER BY Salary DESC) AS RowNumber,
  *
FROM Teachers
)
SELECT * FROM SecondHighest WHERE RowNumber = 2;

-- 2) Fetch All Teachers details with Department Name using INNER JOIN for all Departments.
SELECT		ROW_NUMBER() OVER (ORDER BY TeacherID) AS SrNo,
			Teachers.[Name] AS TeacherName, 
			Specialization, 
			PhoneNo,
			Age,
			City,
			Salary,
			Teachers.DepartmentId,
			DeptRecord.[Name] AS DepartmentName
FROM		Teachers
INNER JOIN	Departments AS DeptRecord 
ON			Teachers.DepartmentId = DeptRecord.DepartmentId

-- 3) Fetch Teacher and Student details of last department using LEFT JOIN.
SELECT	Tea.DepartmentId,
		Tea.[Name] AS TeacherName,
		Tea.Specialization,
		Tea.Salary,
		Tea.City,
		Stu.[Name] AS StudentName,
		Stu.Gender,
		Stu.Age,
		Stu.PhoneNo,
		Dep.[Name] AS Department
FROM	Students AS Stu 
		LEFT JOIN Teachers AS Tea ON Stu.DepartmentId = Tea.DepartmentId
		LEFT JOIN Departments AS Dep ON Dep.DepartmentId = Stu.DepartmentId
WHERE	Dep.DepartmentID = 	(SELECT MAX(DepartmentId) FROM Departments)
------------------------------------


