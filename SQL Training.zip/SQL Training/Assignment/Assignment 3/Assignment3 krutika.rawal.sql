--CREATE DATABASE CollegeSystem
--USE CollegeSystem

SET NOCOUNT ON
DROP TABLE IF EXISTS Students, Teachers,  Departments

--CREATE TABLE
CREATE TABLE Departments(	DepartmentID	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							HOD				VARCHAR(50),
							StaffCount		INT,
							Code			INT
						)

--INSERT TABLE	
INSERT INTO Departments ([Name],HOD,StaffCount,Code) VALUES	('ENTC','Prashant Gaikwad',10,0001),
															('Computer','Gayatri Jagtap',15,0002),
															('Mechanical','Kartik Raghav',16,0003),
															('IT','Swati Desai',10,0004),
															('Electrical','Vikram Podar',12,0005)


--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY DepartmentID) AS SrNo,
		DepartmentID,
		[Name] AS DepartmentName,
		HOD,
		StaffCount,
		Code
FROM	Departments

--CREATE TABLE
CREATE TABLE Teachers	(	TeacherId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							Specialization	VARCHAR(50),
							PhoneNo			VARCHAR(30),
							Age				INT,
							City			VARCHAR(30),
							DepartmentId	INT FOREIGN KEY REFERENCES Departments(DepartmentId)
						)

--INSERT TABLE
INSERT INTO Teachers	([Name], Specialization, PhoneNo, Age, City, DepartmentId) VALUES 
						('Radhika Pawar', 'CyberSecurity', '9874152630', 35, 'Pune', 4),
						('Shivam Rathod', 'MachineDesign', '8874152030', 40, 'nsk', 3),
						('Ragini Shukla', 'ArtificialIntelligence', '9872563014',  37,'Mumbai', 2),
						('Sanjay Mehta', ' EmbeddedSystems', '9748562103', 40, 'nsk', 1),
						('Bhushan Gholap', 'SoftwareTesting', '8874599632', 39, 'nsk', 2),
						('Vaishali Tidke', 'PowerEngineering', '7784455921', 37, 'Delhi', 5),
						('Priyanka Borsate', 'Blockchain', '9847510220', 30, 'Pune', 4),
						('Prathmesh Shirsath', 'DataScience', '9744885120', 35, 'Mumbai', 2),
						('Shivani Wagh', 'ArtificialIntelligence','9992514000', 32, 'Mumbai', 2),
						('Neha Wagh', 'SoftwareTesting','9977885541', 31,  'Pune',4),
						('Swaroop Shinde','EmbeddedSystems','7844551020', 35, 'nsk', 1)

--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY TeacherID) AS SrNo,
		[Name] AS TeacherName, 
		Specialization, 
		PhoneNo,
		Age,
		City,
		DepartmentId
FROM	Teachers

--CREATE TABLE
CREATE TABLE Students	(	StudentId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]			VARCHAR(50),
							Age				INT,
							Gender			VARCHAR(50),
							PhoneNo			VARCHAR(30),
							DepartmentId	INT FOREIGN KEY REFERENCES Departments(DepartmentId)
						)

--INSERT TABLE
INSERT INTO Students	([Name], Age, Gender, PhoneNo, DepartmentId) VALUES
						('Priya Bote', 21, 'Female', '7788445963', 2),
						('Karan Sharma', 22, 'Male', '9784512633', 3),
						('Rashi Chopra', 21, 'Female', '9588747114', 5),
						('Yash Raghuvanshi', 23, 'Male', '7488559661', 3),
						('Seema Nand', 24, 'Female', '8874112256',4),
						('Divya Patil', 22, 'Female', '9874455621', 1),
						('Kiran Bendkoli', 23, 'Male', '9228774563',5),
						('Tanaya Gavande',21, 'Female', '9598774632', 2),
						('Apurva Jadhav',22, 'Female', '7411528220',4)

--SELECT QUERY
SELECT	ROW_NUMBER() OVER (ORDER BY StudentId) AS SrNo,
		[Name] AS StudentName, 
		Age, 
		Gender, 
		PhoneNo, 
		DepartmentId
FROM    Students

--SELECT QUERY FOR TABLES RELATIONSHIP 

--(Students, Departments)
SELECT	Students.[Name] AS StudentName,Students.Age,Students.Gender,
		Departments.[Name] AS DepartmentName,Departments.HOD
FROM	Students, Departments
WHERE	Students.DepartmentId = Departments.DepartmentId

--(Departments,Teachers)
SELECT	Teachers.[Name] AS TeacherName, Teachers.Specialization, Teachers.DepartmentId,
		Departments.[Name] AS DepartmentName,Departments.HOD 		
FROM	Departments,Teachers
WHERE	Teachers.DepartmentId = Departments.DepartmentId
	
--USE OF KEYWORDS

--DISTINCT
SELECT  DISTINCT [Name]
FROM	Students

--CASE
SELECT	Age ,
		CASE WHEN Age >= 23
		THEN 1
		ELSE 0
		END  AS Eligible
FROM	Students

--BETWEEN
SELECT	[Name], Age 
FROM	Teachers
WHERE	Age 
BETWEEN	35 AND 39
	
--AND
SELECT	[Name] AS TeacherName, Specialization, DepartmentId
FROM	Teachers
WHERE	Specialization = 'Blockchain' AND DepartmentId = 4

--OR
SELECT	[Name] AS TeacherName, Specialization, DepartmentId
FROM	Teachers
WHERE	Specialization = 'ArtificialIntelligence' OR DepartmentId = 4

--IN
SELECT	[Name] AS TeacherName, DepartmentId
FROM	Teachers
WHERE	DepartmentId IN(2,4,1)

--EXEC
EXEC	('SELECT DepartmentID, [Name], HOD FROM Departments')

--USE OF FUNCTION
SELECT	CONCAT		('FirstName', ' LastName') AS MyName
SELECT	FORMAT		(04092023, '##-##-####')	AS [Date]
SELECT	LOWER		('ABC@GMAIL.COM')	AS [LOWER]
SELECT	LEFT		('Good Afternoon', 4)	AS [LEFT]
SELECT	RIGHT		('Good Afternoon', 4)	AS [RIGHT]
SELECT	LEN			('Winter')	AS [LENGTH]
SELECT	TRIM		('IT' FROM 'It was a wonderful day')	AS	[TRIM]
SELECT	CHARINDEX	('a', 'Education is a power',6)	AS [CHARINDEX] --Second occurence of 'a'
SELECT	REPLACE		('Good Night', 'Night', 'Morning')	AS [REPLACE]
SELECT	SUBSTRING	('Nashik is a wine city', 13, 21)	AS [SUBSTRING]
--SECURITY PURPOSE
SELECT	REVERSE		('111900102LPj10')	AS [REVERSE]
SELECT	REVERSE		(REVERSE('111900102LPj10'))	AS [REVERSE]

