USE [master]
GO
/****** Object:  Database [Bazaar]    Script Date: 9/7/2023 10:47:05 AM ******/
CREATE DATABASE [Bazaar]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Bazaar', FILENAME = N'C:\Users\krutika.rawal\Bazaar.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Bazaar_log', FILENAME = N'C:\Users\krutika.rawal\Bazaar_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Bazaar] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Bazaar].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Bazaar] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Bazaar] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Bazaar] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Bazaar] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Bazaar] SET ARITHABORT OFF 
GO
ALTER DATABASE [Bazaar] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [Bazaar] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Bazaar] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Bazaar] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Bazaar] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Bazaar] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Bazaar] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Bazaar] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Bazaar] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Bazaar] SET  ENABLE_BROKER 
GO
ALTER DATABASE [Bazaar] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Bazaar] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Bazaar] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Bazaar] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Bazaar] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Bazaar] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Bazaar] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Bazaar] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Bazaar] SET  MULTI_USER 
GO
ALTER DATABASE [Bazaar] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Bazaar] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Bazaar] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Bazaar] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Bazaar] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Bazaar] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Bazaar] SET QUERY_STORE = OFF
GO
USE [Bazaar]
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalAmount]    Script Date: 9/7/2023 10:47:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetTotalAmount]
(
	@Quantity		INT,
	@Price			DECIMAL(18,2),
	@Discount		DECIMAL(18,2)
)
RETURNS DECIMAL (18,2)		
AS
BEGIN	
		RETURN	@Price-((@Price * @Discount/100)* @Quantity)
END
GO
/****** Object:  Table [dbo].[Users]    Script Date: 9/7/2023 10:47:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[PhoneNo] [varchar](30) NULL,
	[Email] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 9/7/2023 10:47:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[ProductId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[Quantity] [int] NULL,
	[Price] [decimal](18, 2) NULL,
	[TotalAmount] [decimal](18, 2) NULL,
	[UserId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[GetUserProductDetail]    Script Date: 9/7/2023 10:47:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetUserProductDetail]
(
	@UserId INT = 0
)
RETURNS TABLE
AS
RETURN
		SELECT		Customer.FirstName,
					Customer.LastName,
					Customer.PhoneNo,
					Customer.Email,
					Items.ProductId,
					Items.[Name] AS ProductName,
					Items.Quantity,
					Items.Price ,
					Items.UserId
		FROM		Users	Customer
		INNER JOIN  Products AS Items
		ON			Customer.UserId = Items.UserId
		WHERE		Customer.UserId = @UserId
GO
SET IDENTITY_INSERT [dbo].[Products] ON 
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (1, N'SunsCream', 2, CAST(80.00 AS Decimal(18, 2)), NULL, 4)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (2, N'Foundation', 4, CAST(50.00 AS Decimal(18, 2)), NULL, 3)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (3, N'Shampoo', 6, CAST(5.00 AS Decimal(18, 2)), NULL, 5)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (4, N'Maggie', 10, CAST(12.00 AS Decimal(18, 2)), NULL, 7)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (5, N'ChipsPacket', 8, CAST(10.00 AS Decimal(18, 2)), NULL, 6)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (6, N'Milk', 3, CAST(75.00 AS Decimal(18, 2)), NULL, 2)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (7, N'Oil', 5, CAST(100.00 AS Decimal(18, 2)), NULL, 1)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (8, N'FaceMask', 7, CAST(45.00 AS Decimal(18, 2)), NULL, 4)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (9, N'FaceWash', 2, CAST(70.00 AS Decimal(18, 2)), NULL, 3)
GO
INSERT [dbo].[Products] ([ProductId], [Name], [Quantity], [Price], [TotalAmount], [UserId]) VALUES (10, N'HandWash', 5, CAST(40.00 AS Decimal(18, 2)), NULL, 5)
GO
SET IDENTITY_INSERT [dbo].[Products] OFF
GO
SET IDENTITY_INSERT [dbo].[Users] ON 
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (1, N'Priya', N'Bote', N'7788445963', N'pb@gmail.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (2, N'Rashi', N'Chopra', N'9874152630', N'rc@gmail.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (3, N'Karan', N'Sharma', N'8874599632', N'kc@gmail.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (4, N'Tanaya', N'Gavande', N'7784455921', N'tg@gamil.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (5, N'Seema', N'Wagh', N'9977885541', N'sw@gmail.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (6, N'Yash', N'Nand', N'7844551020', N'yn@gmail.com')
GO
INSERT [dbo].[Users] ([UserId], [FirstName], [LastName], [PhoneNo], [Email]) VALUES (7, N'Divya', N'Patil', N'9872563014', N'dp@gmail.com')
GO
SET IDENTITY_INSERT [dbo].[Users] OFF
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
/****** Object:  StoredProcedure [dbo].[GetDetails]    Script Date: 9/7/2023 10:47:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetDetails]
@case		INT = 0,
@UserId		INT,
@Discount	DECIMAL(18,2)= 0
AS
BEGIN
	SET NOCOUNT ON
	IF	( @case = 1)
		SELECT * FROM [dbo].[GetUserProductDetail](@UserId)
	IF	(@case = 2)
		
		SELECT		CONCAT (Customer.FirstName,Customer.LastName) AS [Name],
							Items.ProductId,
							Items.[Name] AS ProductName,
							Items.Quantity,
							Items.Price,
							CONCAT(@Discount,'') AS Discount,
							Items.UserId,
							[dbo].[GetTotalAmount] (Items.Quantity,Items.Price,@Discount) as Total							
		FROM				Users	Customer
		INNER JOIN			Products AS Items
		ON					Customer.UserId = Items.UserId
		WHERE				Customer.UserId = @UserId
END	
GO
USE [master]
GO
ALTER DATABASE [Bazaar] SET  READ_WRITE 
GO
