--CREATE DATABASE Bazaar
--USE Bazaar

DROP TABLE IF EXISTS Products, Users
DROP FUNCTION IF EXISTS GetUserProductDetail,GetTotalAmount
DROP PROCEDURE IF EXISTS GetDetails 
----------------------------------------------------------------------------------------
--CREATE TABLE USERS
CREATE TABLE Users	(
						UserId		INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
						FirstName	VARCHAR(50),
						LastName	VARCHAR(50),
						PhoneNo		VARCHAR(30),
						Email		VARCHAR(50),
					) 

--INSERT RECORD INTO USERS
INSERT INTO Users	(FirstName,LastName,PhoneNo,Email) VALUES
					('Priya', 'Bote', '7788445963', 'pb@gmail.com'),
					('Rashi', 'Chopra', '9874152630', 'rc@gmail.com'),
					('Karan', 'Sharma', '8874599632', 'kc@gmail.com'),
					('Tanaya', 'Gavande', '7784455921', 'tg@gamil.com'),
					('Seema', 'Wagh', '9977885541', 'sw@gmail.com'),
					('Yash', 'Nand', '7844551020', 'yn@gmail.com'),
					('Divya', 'Patil', '9872563014', 'dp@gmail.com')

--SELECT QUERY
SELECT	UserId,
		FirstName,
		LastName,
		PhoneNo,
		Email
FROM	Users
---------------------------------------------------------------------------------------------------
--CREATE TABLE Products

CREATE TABLE Products	(
							ProductId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
							[Name]		VARCHAR(50),
							Quantity	INT,
							Price		DECIMAL(18,2),
							TotalAmount	DECIMAL(18,2),
							UserId		INT FOREIGN KEY REFERENCES Users(UserId)
						)

--INSERT RECORDS INTO PRODUCTS
INSERT INTO Products	( [Name], Quantity,Price, UserId) 
VALUES					('SunsCream', 2, 80, 4),
						('Foundation', 4, 50, 3),
						('Shampoo', 6, 5,5),
						('Maggie',10 , 12 ,7),
						('ChipsPacket',8 ,10 ,6),
						('Milk',3 ,75 ,2),
						('Oil',5 ,100 ,1),
						('FaceMask', 7,45,4),
						('FaceWash',2, 70, 3),
						('HandWash',5, 40, 5)

--SELECT QUERY
SELECT	ProductId,
		[Name] AS ProductName,
		Quantity,
		Price, 
		UserId
FROM	Products
----------------------------------------------------------------------------
--CREATE FUNCTION GetUserProductDetail
CREATE FUNCTION [dbo].[GetUserProductDetail]
(
	@UserId INT = 0
)
RETURNS TABLE
AS
RETURN
		SELECT		Customer.FirstName,
					Customer.LastName,
					Customer.PhoneNo,
					Customer.Email,
					Items.ProductId,
					Items.[Name] AS ProductName,
					Items.Quantity,
					Items.Price ,
					Items.UserId
		FROM		Users	Customer
		INNER JOIN  Products AS Items
		ON			Customer.UserId = Items.UserId
		WHERE		Customer.UserId = @UserId
--EXAMINE--
SELECT * FROM [dbo].[GetUserProductDetail](5)

-------------------------------------------------------
--CREATE FUNCTION GetTotalAmount
CREATE FUNCTION [dbo].[GetTotalAmount]
(
	@Quantity		INT,
	@Price			DECIMAL(18,2),
	@Discount		DECIMAL(18,2)
)
RETURNS DECIMAL (18,2)		
AS
BEGIN	
		RETURN	@Price-((@Price * @Discount/100)* @Quantity)
END

--EXAMINE--
SELECT [dbo].[GetTotalAmount] (4,500,0.5) AS Discount
-------------------------------------------------------------
--CREATE PROCEDURE
CREATE PROCEDURE [dbo].[GetDetails]
	@case		INT = 0,
	@UserId		INT,
	@Discount	DECIMAL(18,2)= 0
AS
BEGIN
	SET NOCOUNT ON
	IF	( @case = 1)
		SELECT * FROM [dbo].[GetUserProductDetail](@UserId)
	IF	(@case = 2)
		
		SELECT		CONCAT (Customer.FirstName,Customer.LastName) AS [Name],
							Items.ProductId,
							Items.[Name] AS ProductName,
							Items.Quantity,
							Items.Price,
							CONCAT(@Discount,'') AS Discount,
							Items.UserId,
							[dbo].[GetTotalAmount] (Items.Quantity,Items.Price,@Discount) as Total							
		FROM				Users	Customer
		INNER JOIN			Products AS Items
		ON					Customer.UserId = Items.UserId
		WHERE				Customer.UserId = @UserId
END	

--case 1 (call)
EXECUTE GetDetails 1,6

--case 2 (call)
EXECUTE GetDetails 2,2,0.5